<template>
  <div class="contact">
    <h1>Contact</h1>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.contact {
  background: #97ff75;
  width: 100%;
  min-height: 91vh;
  display: flex;
  justify-content: center;
  padding-top: 30vh;
}
</style>