<template>
  <div class="home">
    <h1>Home</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>

.home {
  background: #99BBFF;
  width: 100%;
  min-height: 91vh;
  display: flex;
  justify-content: center;
  padding-top: 30vh;
}

</style>