<template>
  <div class="info">
    <h1>Info</h1>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.info {
  background: #ffa775;
  width: 100%;
  min-height: 91vh;
  display: flex;
  justify-content: center;
  padding-top: 30vh;
}
</style>