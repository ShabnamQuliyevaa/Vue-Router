<template>
  <div class="about">
    <h1>About</h1>
  </div>
</template>

<script>
export default {};
</script>

<style scoped>
.about {
  background: #e475ff;
  width: 100%;
  min-height: 91vh;
  display: flex;
  justify-content: center;
  padding-top: 30vh;
}
</style>