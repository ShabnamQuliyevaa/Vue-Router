<script setup>
import { RouterLink, RouterView } from "vue-router";
</script>

<template>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
      <button
        class="navbar-toggler"
        type="button"
        data-bs-toggle="collapse"
        data-bs-target="#navbarSupportedContent"
        aria-controls="navbarSupportedContent"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <RouterLink to="/" tag="li" class="nav-item" active-class="active"
            ><a class="nav-link active" aria-current="page">Home</a></RouterLink
          >
          <RouterLink
            to="/about"
            tag="li"
            class="nav-item"
            active-class="active"
            ><a class="nav-link active" aria-current="page"
              >About</a
            ></RouterLink
          >
          <RouterLink
            to="/contact"
            tag="li"
            class="nav-item"
            active-class="active"
            ><a class="nav-link active" aria-current="page"
              >Contact</a
            ></RouterLink
          >
          <RouterLink to="/info" tag="li" class="nav-item" active-class="active"
            ><a class="nav-link active" aria-current="page">Info</a></RouterLink
          >
        </ul>
      </div>
    </div>
  </nav>
  <transition name="scale">
    <RouterView />
  </transition>
  <div></div>
</template>


<script>
export default {};
</script>

<style >

.nav-item {
border-radius: 10px;
margin-left: 20px;
}


.nav-item:hover {
  background-color: #ddd;
  cursor: pointer;
  transition: all .5s;
  transform: scale(1.1);
}

.router-link-exact-active {
  background-color: #ddd;
  cursor: pointer;
  transform: scale(1.1);
}

body {
  overflow: hidden;
}

a {
  text-decoration: none;
}

.scale-enter-active,
.scale-leave-active {
  transition: all .6s ease;
}

.scale-enter-from,
.scale-leave-to {
  opacity: 0;
  transform: scale(0.5);
}
</style>
